$(document).ready(function() {
	$('.humburger').click(function() {
		$('.humburger').toggleClass('active');
		$('.header ul').toggleClass('active');
	});	
});